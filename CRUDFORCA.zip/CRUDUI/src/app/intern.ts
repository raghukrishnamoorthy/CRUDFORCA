export class Intern {
    id: number;
    name: string;
    age: number;
    departmentId: number;
}

