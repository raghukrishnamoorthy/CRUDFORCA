import { Intern } from './intern';

export class Department {

    id: number;
    name: string;
    interns: null | Intern[];

}
